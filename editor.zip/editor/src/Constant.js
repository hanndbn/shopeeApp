var SERVER_API_URL = 'https://us-central1-silverbullet-sandbox.cloudfunctions.net/api';
var CONSTANT = {
  SAVE_NAME_API: SERVER_API_URL + '/saveApp'
};
